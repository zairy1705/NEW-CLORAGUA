/**
 * Video Game Sound Engine (Retro 8-Bit / Arcade Web Audio Synthesizer)
 * Synthesizes zero-latency retro video game sound effects using the Web Audio API.
 * Automatically intercepts button interactions to play classic arcade sound effects.
 */

class GameSoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private isInitialized: boolean = false;

  // --- Calypso BGM (Background Music) state ---
  private bgmMasterGain: GainNode | null = null;
  private bgmTimer: number | null = null;
  private nextBeatTime: number = 0;
  private currentBeat: number = 0;
  private bgmLoopCount: number = 0;
  private isBgmPlaying: boolean = false;
  private isBgmMuted: boolean = true; // BGM starts off by default (browser autoplay policy)
  private readonly bgmTempoBpm: number = 104;

  constructor() {
    // Check localStorage preference, default to true (sound enabled)
    try {
      const saved = localStorage.getItem('cloragua_game_sound_enabled');
      if (saved !== null) {
        this.isMuted = saved === 'false';
      }
    } catch {
      this.isMuted = false;
    }

    try {
      const savedBgm = localStorage.getItem('cloragua_bgm_enabled');
      if (savedBgm !== null) {
        this.isBgmMuted = savedBgm !== 'true';
      }
    } catch {
      this.isBgmMuted = true;
    }
  }

  /**
   * Safe getter for Web Audio Context with auto-resume
   */
  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;

    if (!this.ctx) {
      const AudioContextClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    return this.ctx;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    try {
      localStorage.setItem('cloragua_game_sound_enabled', String(!muted));
    } catch {}
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public toggleSound(): boolean {
    this.setMuted(!this.isMuted);
    if (!this.isMuted) {
      this.playCoin();
    }
    return !this.isMuted;
  }

  /**
   * Sound 1: Classic Arcade Coin / Crystal Pickup
   * Iconic dual-frequency arpeggio (B5 -> E6)
   */
  public playCoin(pitchVariance = 0.05, volume = 0.18): void {
    if (this.isMuted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const variation = 1 + (Math.random() - 0.5) * pitchVariance;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      // Vintage square wave gives that iconic Nintendo/Arcade game feel
      osc.type = 'square';

      // First note: B5 (~987 Hz)
      osc.frequency.setValueAtTime(987.77 * variation, now);
      // Second note: E6 (~1318 Hz) after 75ms
      osc.frequency.setValueAtTime(1318.51 * variation, now + 0.075);

      // Volume envelope: snappy arcade attack and soft decay
      gain.gain.setValueAtTime(volume, now);
      gain.gain.setValueAtTime(volume, now + 0.075);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.32);

      // Lowpass filter to smooth harsh harmonics slightly
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(4500, now);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.33);
    } catch {
      // Best effort audio playback
    }
  }

  /**
   * Sound 2: 8-Bit Laser / Action Blip
   * Rapid downwards frequency slide
   */
  public playBlip(pitchVariance = 0.1, volume = 0.16): void {
    if (this.isMuted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const variation = 1 + (Math.random() - 0.5) * pitchVariance;
      const baseFreq = 880 * variation;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(baseFreq, now);
      osc.frequency.exponentialRampToValueAtTime(220, now + 0.1);

      gain.gain.setValueAtTime(volume, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.11);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.12);
    } catch {}
  }

  /**
   * Sound 3: Retro Jump / Spring Sound
   * Upward frequency glide with snappy decay
   */
  public playJump(volume = 0.15): void {
    if (this.isMuted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'square';
      osc.frequency.setValueAtTime(150, now);
      osc.frequency.exponentialRampToValueAtTime(620, now + 0.14);

      gain.gain.setValueAtTime(volume, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.15);

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(3200, now);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.16);
    } catch {}
  }

  /**
   * Sound 4: Power-Up / Level-Up Major Arpeggio
   */
  public playPowerUp(volume = 0.16): void {
    if (this.isMuted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.055);

        gain.gain.setValueAtTime(volume, now + idx * 0.055);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.055 + 0.18);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + idx * 0.055);
        osc.stop(now + idx * 0.055 + 0.19);
      });
    } catch {}
  }

  /**
   * Sound 5: Arcade Select / Menu Navigation Click
   * Crisp, high-tech video game menu tick
   */
  public playMenuSelect(volume = 0.14): void {
    if (this.isMuted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      // Crisp 1400 Hz arcade confirmation blip with quick octave slide
      osc.frequency.setValueAtTime(900 + Math.random() * 200, now);
      osc.frequency.exponentialRampToValueAtTime(1600, now + 0.04);

      gain.gain.setValueAtTime(volume, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.06);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.07);
    } catch {}
  }

  /**
   * Sound 6: Subtle Hover Chirp (when cursor hovers on buttons)
   */
  public playHoverChirp(volume = 0.04): void {
    if (this.isMuted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(1200 + Math.random() * 150, now);
      osc.frequency.exponentialRampToValueAtTime(1800, now + 0.025);

      gain.gain.setValueAtTime(volume, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.035);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.04);
    } catch {}
  }

  /**
   * Global video game sound dispatcher for clicks
   * Chooses the best video game sound depending on context or button role
   */
  public playRandomVideoGameSound(targetElement?: Element | null): void {
    if (this.isMuted) return;

    // Check element text or attributes for context
    const text = (targetElement?.textContent || '').toLowerCase();
    const isSpecialAction =
      text.includes('calcular') ||
      text.includes('guardar') ||
      text.includes('completar') ||
      text.includes('registrar') ||
      text.includes('dosis');

    if (isSpecialAction) {
      // Iconic coin / crystal reward
      this.playCoin(0.08, 0.2);
    } else if (text.includes('saludar') || text.includes('subir') || text.includes('siguiente')) {
      this.playJump(0.16);
    } else {
      // Crisp 8-bit arcade click
      const r = Math.random();
      if (r < 0.45) {
        this.playCoin(0.12, 0.16);
      } else if (r < 0.75) {
        this.playMenuSelect(0.18);
      } else {
        this.playBlip(0.1, 0.16);
      }
    }
  }

  // =========================================================================
  // Sintetizador de Música de Fondo (BGM Calypso Tropical)
  // Genera en tiempo real música tropical sin necesidad de archivos .mp3
  // =========================================================================

  /** Master Gain de la Música (independiente del volumen de los efectos) */
  private getBgmGain(ctx: AudioContext): GainNode {
    if (!this.bgmMasterGain) {
      this.bgmMasterGain = ctx.createGain();
      this.bgmMasterGain.gain.setValueAtTime(0.34, ctx.currentTime);
      this.bgmMasterGain.connect(ctx.destination);
    }
    return this.bgmMasterGain;
  }

  /** 1. Steel Pan Tropical: fundamental + sobretono metálico armónico (2.76x) */
  private synthSteelDrum(ctx: AudioContext, freq: number, t: number, durSec: number): void {
    const master = this.getBgmGain(ctx);

    const osc1 = ctx.createOscillator();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(freq, t);

    const osc2 = ctx.createOscillator();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(freq * 2.76, t);

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(freq * 1.8, t);
    filter.Q.value = 2.4;

    const gain1 = ctx.createGain();
    gain1.gain.setValueAtTime(0.0001, t);
    gain1.gain.linearRampToValueAtTime(0.25, t + 0.008);
    gain1.gain.exponentialRampToValueAtTime(0.0001, t + Math.min(durSec * 1.1, 0.45));

    const gain2 = ctx.createGain();
    gain2.gain.setValueAtTime(0.0001, t);
    gain2.gain.linearRampToValueAtTime(0.09, t + 0.006);
    gain2.gain.exponentialRampToValueAtTime(0.0001, t + Math.min(durSec * 0.8, 0.3));

    osc1.connect(filter);
    filter.connect(gain1);
    gain1.connect(master);

    osc2.connect(gain2);
    gain2.connect(master);

    osc1.start(t);
    osc1.stop(t + 0.5);
    osc2.start(t);
    osc2.stop(t + 0.35);
  }

  /** 2. Pluck Acuático: barrido de frecuencia ascendente (gota de agua) */
  private synthBubblePluck(ctx: AudioContext, t: number, baseFreq = 600): void {
    const master = this.getBgmGain(ctx);

    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(baseFreq * 0.5, t);
    osc.frequency.exponentialRampToValueAtTime(baseFreq * 2.2, t + 0.09);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.linearRampToValueAtTime(0.14, t + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);

    osc.connect(gain);
    gain.connect(master);

    osc.start(t);
    osc.stop(t + 0.18);
  }

  /** 3. Campanilla: onda sinusoidal brillante con capa desafinada (shimmer) */
  private synthChimeNote(ctx: AudioContext, freq: number, t: number): void {
    const master = this.getBgmGain(ctx);

    const osc1 = ctx.createOscillator();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(freq, t);

    const osc2 = ctx.createOscillator();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(freq * 2.005, t); // ligeramente desafinado -> brillo

    const gain1 = ctx.createGain();
    gain1.gain.setValueAtTime(0.0001, t);
    gain1.gain.linearRampToValueAtTime(0.1, t + 0.01);
    gain1.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);

    const gain2 = ctx.createGain();
    gain2.gain.setValueAtTime(0.0001, t);
    gain2.gain.linearRampToValueAtTime(0.035, t + 0.01);
    gain2.gain.exponentialRampToValueAtTime(0.0001, t + 0.6);

    osc1.connect(gain1);
    gain1.connect(master);
    osc2.connect(gain2);
    gain2.connect(master);

    osc1.start(t);
    osc1.stop(t + 1);
    osc2.start(t);
    osc2.stop(t + 0.7);
  }

  /** 4. Bajo Calypso: onda redonda con filtro pasa-bajos cálido */
  private synthBassNote(ctx: AudioContext, freq: number, t: number, durSec: number): void {
    const master = this.getBgmGain(ctx);

    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, t);

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(420, t);
    filter.Q.value = 0.8;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.linearRampToValueAtTime(0.22, t + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + durSec);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(master);

    osc.start(t);
    osc.stop(t + durSec + 0.05);
  }

  /** 5. Bongó Caribeño: golpe rápido con caída de frecuencia percusiva */
  private synthBongo(ctx: AudioContext, t: number, high: boolean): void {
    const master = this.getBgmGain(ctx);

    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    const startFreq = high ? 420 : 240;
    osc.frequency.setValueAtTime(startFreq, t);
    osc.frequency.exponentialRampToValueAtTime(startFreq * 0.55, t + 0.09);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(high ? 0.16 : 0.19, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.11);

    osc.connect(gain);
    gain.connect(master);

    osc.start(t);
    osc.stop(t + 0.12);
  }

  /** 6. Maraca / Shaker: ruido blanco filtrado con envolvente exponencial */
  private synthMaraca(ctx: AudioContext, t: number, accent: boolean): void {
    const master = this.getBgmGain(ctx);

    const bufferSize = Math.floor(ctx.sampleRate * 0.035);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.3));
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(accent ? 7200 : 5800, t);
    filter.Q.value = 2.0;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(accent ? 0.12 : 0.06, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + (accent ? 0.045 : 0.03));

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(master);
    noise.start(t);
    noise.stop(t + 0.05);
  }

  // --- Patrón musical Calypso (16 pasos = 2 compases de corcheas en 4/4) ---
  // Escala pentatónica mayor de Do, dos octavas, ideal para steel pan
  private readonly bgmScale = [523.25, 587.33, 659.25, 783.99, 880.0, 1046.5]; // C5 D5 E5 G5 A5 C6
  private readonly bgmBassNotes = [130.81, 146.83, 196.0]; // C3 D3 G3

  // Melodía: índice en bgmScale, null = silencio
  private readonly bgmMelodyPattern: (number | null)[] = [
    0, null, 2, 3, null, 3, 4, 3,
    0, null, 1, 3, null, 4, 2, null,
  ];
  // Bajo: índice en bgmBassNotes, null = silencio (patrón sincopado calypso)
  private readonly bgmBassPattern: (number | null)[] = [
    0, null, null, 0, null, null, 2, null,
    0, null, null, 0, null, null, 2, null,
  ];
  // Bongó: 'low' | 'high' | null
  private readonly bgmBongoPattern: ('low' | 'high' | null)[] = [
    'low', null, 'high', null, 'low', null, 'high', 'high',
    'low', null, 'high', null, 'low', null, 'high', 'high',
  ];
  // Maraca: se toca en cada paso, con acento en los tiempos fuertes
  private readonly bgmMaracaAccents = new Set([0, 4, 8, 12]);

  /** Programa un único paso del patrón calypso en el instante `time` */
  private scheduleBgmStep(ctx: AudioContext, step: number, time: number, stepDur: number): void {
    // Melodía (steel pan)
    const melodyIdx = this.bgmMelodyPattern[step];
    if (melodyIdx !== null) {
      this.synthSteelDrum(ctx, this.bgmScale[melodyIdx], time, stepDur * 0.9);
    }

    // Bajo
    const bassIdx = this.bgmBassPattern[step];
    if (bassIdx !== null) {
      this.synthBassNote(ctx, this.bgmBassNotes[bassIdx], time, stepDur * 3.6);
    }

    // Bongó
    const bongo = this.bgmBongoPattern[step];
    if (bongo) {
      this.synthBongo(ctx, time, bongo === 'high');
    }

    // Maraca / Shaker en cada paso
    this.synthMaraca(ctx, time, this.bgmMaracaAccents.has(step));

    // Adornos ambientales: pluck de agua y campanilla, una vez por vuelta del patrón
    if (step === 15) {
      this.synthBubblePluck(ctx, time + stepDur * 0.3, 700);
      if (this.bgmLoopCount % 3 === 0) {
        this.synthChimeNote(ctx, this.bgmScale[3] * 2, time + stepDur * 0.5);
      }
      this.bgmLoopCount++;
    }
  }

  /** Planificador con look-ahead (patrón estándar de Web Audio API) */
  private bgmScheduler = (): void => {
    if (!this.ctx || !this.isBgmPlaying) return;
    const ctx = this.ctx;
    const stepDur = 60 / this.bgmTempoBpm / 2; // duración de una corchea
    const scheduleAheadTime = 0.15;

    while (this.nextBeatTime < ctx.currentTime + scheduleAheadTime) {
      this.scheduleBgmStep(ctx, this.currentBeat, this.nextBeatTime, stepDur);
      this.nextBeatTime += stepDur;
      this.currentBeat = (this.currentBeat + 1) % this.bgmMelodyPattern.length;
    }
  };

  /** Inicia la reproducción de la música de fondo Calypso */
  public startBgm(): void {
    if (this.isBgmMuted) return;
    const ctx = this.getContext();
    if (!ctx) return;
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});

    if (this.isBgmPlaying) return;
    this.isBgmPlaying = true;
    this.nextBeatTime = ctx.currentTime + 0.05;
    this.currentBeat = 0;
    this.bgmLoopCount = 0;

    if (this.bgmTimer) window.clearInterval(this.bgmTimer);
    this.bgmTimer = window.setInterval(this.bgmScheduler, 35);
  }

  /** Detiene la reproducción de la música de fondo */
  public stopBgm(): void {
    this.isBgmPlaying = false;
    if (this.bgmTimer) {
      window.clearInterval(this.bgmTimer);
      this.bgmTimer = null;
    }
  }

  /** Activa/desactiva la música de fondo y guarda la preferencia */
  public toggleBgm(): boolean {
    this.isBgmMuted = !this.isBgmMuted;
    try {
      localStorage.setItem('cloragua_bgm_enabled', String(!this.isBgmMuted));
    } catch {
      /* best effort */
    }

    if (this.isBgmMuted) {
      this.stopBgm();
    } else {
      this.startBgm();
    }
    return !this.isBgmMuted;
  }

  /** Indica si la música de fondo está activa en este momento */
  public isBgmActive(): boolean {
    return this.isBgmPlaying;
  }

  /** Indica si la música de fondo está silenciada (preferencia guardada) */
  public getBgmMuted(): boolean {
    return this.isBgmMuted;
  }

  /**
   * Setup global DOM event listeners for buttons
   */
  public setupGlobalListeners(): void {
    if (this.isInitialized || typeof window === 'undefined') return;
    this.isInitialized = true;

    // Helper to find clickable button target
    const findButtonTarget = (el: EventTarget | null): HTMLElement | null => {
      let curr = el as HTMLElement | null;
      let depth = 0;
      while (curr && depth < 6 && curr !== document.body) {
        if (
          curr.tagName === 'BUTTON' ||
          curr.getAttribute('role') === 'button' ||
          curr.classList?.contains('btn') ||
          (curr.tagName === 'A' && curr.getAttribute('href')) ||
          (curr.tagName === 'INPUT' &&
            (curr.getAttribute('type') === 'button' ||
              curr.getAttribute('type') === 'submit' ||
              curr.getAttribute('type') === 'checkbox' ||
              curr.getAttribute('type') === 'radio'))
        ) {
          return curr;
        }
        curr = curr.parentElement;
        depth++;
      }
      return null;
    };

    // 1. Pointerdown/Click: Play retro video game sound!
    window.addEventListener(
      'pointerdown',
      (e: PointerEvent) => {
        // Unlock audio context on interaction
        this.getContext();

        // If the user had Calypso BGM enabled in a previous session, resume it
        // as soon as the browser allows audio (first user gesture).
        if (!this.isBgmMuted && !this.isBgmPlaying) {
          this.startBgm();
        }

        const btn = findButtonTarget(e.target);
        if (btn) {
          // Play video game sound immediately
          this.playRandomVideoGameSound(btn);
        }
      },
      { capture: true, passive: true }
    );

    // 2. Mouseenter: Optional delicate arcade tick on hover
    let lastHoverTime = 0;
    window.addEventListener(
      'mouseover',
      (e: MouseEvent) => {
        const now = Date.now();
        // Debounce hover ticks so rapid movements across nested elements feel pleasant
        if (now - lastHoverTime < 80) return;

        const btn = findButtonTarget(e.target);
        if (btn) {
          lastHoverTime = now;
          this.playHoverChirp(0.03);
        }
      },
      { capture: true, passive: true }
    );
  }
}

export const gameSoundEngine = new GameSoundEngine();
